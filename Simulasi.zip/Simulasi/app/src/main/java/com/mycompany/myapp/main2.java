package com.mycompany.myapp;
import android.content.*;
import android.os.*;
import android.support.v7.app.*;
import android.view.*;
import android.widget.*;

public class main2 extends AppCompatActivity
{
	private String user, pass;
	private TextView well;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState );
		setContentView(R.layout.menus1);
		Intent i =  getIntent();
		user = i.getExtras().get("user").toString();
		pass = i.getExtras().get("pass").toString();
		setintent();
	}
	public void setintent(){
		well = (TextView) findViewById(R.id.well);
		well.setText("Welcome: " + this.user + "\nPassword: "+ this.pass);
		
	}
	public void menu(View klik){
		String set = String.valueOf(klik.getId());
		switch(klik.getId()){
			case R.id.menawar:
				this.setmessage(set);
				break;
			case R.id.mk:
				this.setmessage(set);
				break;
			case R.id.nilai:
				setContentView(R.layout.actions);
				this.setmessage(set);
				break;
			case R.id.allmk:
				this.setmessage(set);
				break;
			case R.id.exit:
				this.setmessage(set);
				Intent i = new Intent(getApplicationContext(), MainActivity.class);
				startActivity(i);
				break;
			case R.id.about:
				setContentView(R.layout.abouts);
				this.setmessage(set);
				break;
			}
	}
	public void setmessage(String txt){
		Toast.makeText(getApplicationContext(), txt, Toast.LENGTH_LONG).show();
	}
	

	@Override
	public void onBackPressed()
	{
		
		setContentView(R.layout.menus1);
		setintent();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
	}
}
