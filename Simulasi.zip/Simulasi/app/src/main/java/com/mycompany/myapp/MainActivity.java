package com.mycompany.myapp;

import android.os.*;
import android.support.v7.app.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import javax.security.auth.*;

public class MainActivity extends AppCompatActivity
{
	private EditText user;
	private Button go;
	private EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		user = (EditText) findViewById(R.id.mainEditText2);
		text = (EditText) findViewById(R.id.mainEditText);
		go = (Button) findViewById(R.id.login);
		//Aksi tombol login di pencet 
		go.setOnClickListener( new OnClickListener( ){
				@Override
				public void onClick(View p1)
				{
					/*
					
					Algo:
					ketika tombol di pencet, saya memberikan kondisi.
					saya mengambil patokan sebagai berikut.
					
					Tombol di pencet ketika user dan password kosong,
					saya akan menampilkan semacam info untuk
					memberitau user "Lengkapi Isian Loginnya mass" dengan menggunkan Toast.
					
					selanjutnya jika user dan text tidak kosong
					jalankan fungsi setpasword()
					lalu kemudian finish()
					
					Kesimppppulan: 
					jadi harapan saya, aktifitas selanjutnya tidak akan teertampil
					jikalau user tidak mengisi lembar LOGIN.
					
					*/
					
					
					
					
					//Jika input dari user, berupa var user dan text itu kosong
					if(user.getText().toString().isEmpty() || text.getText().toString().isEmpty()){
						//Munculkan Toast peringatan
						Toast.makeText(MainActivity.this, "Lengkapi Isian Loginnya mass", Toast.LENGTH_SHORT).show();
					}else{
						//Jika inputan keduanya berisi maka lakukan ini
						Toast.makeText(getApplicationContext(), user.getText().toString(), Toast.LENGTH_SHORT).show();
						setpassword();
						finish();
					}
				}
			} );
    }
	private void setpassword(){
		//deklaraaasi untuk menuju menu, dari class MainAaactivit ke class main2
		Intent i = new Intent(getApplicationContext(), main2.class);
		//Mengambil inputan user dan password dari layout Login (main.xml)
		i.putExtra("user",user.getText().toString());
		i.putExtra("pass",text.getText().toString());
		//Menuju ke class main2
		startActivity(i);
	}
}
